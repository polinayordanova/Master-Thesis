$(document).ready(function() {
    $('span[class="word"]').mouseover(function () {
        $(this).addClass('alignment-hover');
        $(this).addClass('alignment-hover-primary')
        ids = $(this).attr('data-refs').split(' ');
        $.each(ids, function (index, id) {
            $('#' + id).addClass('alignment-hover');
        });
    });

    $('span[class="word"]').mouseout(function () {
        $(this).removeClass('alignment-hover');
        $(this).removeClass('alignment-hover-primary');
        ids = $(this).attr('data-refs').split(' ');
        $.each(ids, function (index, id) {
            $('#' + id).removeClass('alignment-hover');
        });
    });
});
